-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-02-2024 a las 14:34:55
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `universidad_pamplona`
--
CREATE DATABASE IF NOT EXISTS `universidad_pamplona` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `universidad_pamplona`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `egresados`
--

CREATE TABLE IF NOT EXISTS `egresados` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `carrera` varchar(255) DEFAULT NULL,
  `ano_graduacion` year(4) DEFAULT NULL,
  `salario_promedio` double DEFAULT NULL,
  `continua_estudios` tinyint(1) DEFAULT NULL,
  `tiempo_conseguir_empleo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `egresados`
--

INSERT INTO `egresados` (`id`, `nombre`, `carrera`, `ano_graduacion`, `salario_promedio`, `continua_estudios`, `tiempo_conseguir_empleo`) VALUES
(11037436, 'Andrea Gomez', 'Derecho', '2022', 3300000, 0, 1),
(11061101, 'Alejandro Castro', 'Lic. en Ciencias Sociales y Desarrollo Local', '2017', 3100000, 1, 4),
(11066034, 'Laura Diaz', 'Economía', '2020', 3200000, 1, 4),
(11071437, 'Valentina Diaz', 'Lic. en Educación Infantil', '2021', 2900000, 0, 4),
(11077452, 'Ana Lopez', 'Ingeniería Civil', '2016', 3500000, 1, 1),
(11077921, 'Javier Ramirez', 'Licenciatura en Educación Infantil', '2022', 3000000, 0, 4),
(11083929, 'Valentina Herrera', 'Terapia Ocupacional', '2020', 3300000, 1, 2),
(11086366, 'Adriana Castro', 'Lic. en Lenguas Extranjeras', '2021', 3500000, 0, 2),
(11095004, 'Valentina Rodriguez', 'Química', '2022', 4200000, 1, 4),
(11096932, 'Laura Gomez', 'Lic. en Educación Física Recreación y Deportes', '2023', 3000000, 1, 4),
(11117495, 'Mauricio Gonzalez', 'Ingeniería Mecánica', '2023', 4000000, 0, 2),
(11125938, 'Mauricio Rodriguez', 'Ingeniería de Sistemas', '2022', 4000000, 1, 2),
(11133351, 'Andres Lopez', 'Diseño Industrial', '2016', 3500000, 1, 1),
(11134798, 'Laura Ramirez', 'Licenciatura en Educación Artística', '2020', 2700000, 1, 3),
(11136989, 'Daniel Herrera', 'Ingeniería Industrial', '2023', 4200000, 0, 4),
(11155035, 'Sofia Mendoza', 'Lic. en Educación Infantil', '2018', 3000000, 0, 3),
(11156181, 'Sandra Jimenez', 'Ingeniería Ambiental', '2025', 3000000, 0, 2),
(11179584, 'Carlos Ramirez', 'Derecho', '2016', 3000000, 0, 2),
(11185357, 'Daniel Torres', 'Fisioterapia', '2022', 3400000, 0, 3),
(11234861, 'Catalina Ramirez', 'Bacteriología y Laboratorio Clínico', '2018', 2900000, 0, 2),
(11238328, 'Isabella Herrera', 'Diseño Industrial', '2024', 3800000, 1, 3),
(11248745, 'Eduardo Castro', 'Ingeniería Industrial', '2020', 4200000, 0, 4),
(11279146, 'Natalia Rodriguez', 'Ingeniería Mecánica', '2022', 4000000, 1, 1),
(11317386, 'Daniela Puentes', 'Ingeniería de Sistemas', '2017', 3100000, 1, 1),
(11318378, 'Santiago Torres', 'Ingeniería de Sistemas', '2024', 3200000, 0, 1),
(11318905, 'Gustavo Hernandez', 'Ingeniería de Alimentos', '2021', 3100000, 1, 2),
(11341708, 'Gabriela Castro', 'Nutrición y Dietética', '2018', 3200000, 1, 4),
(11359334, 'Javier Torres', 'Fisioterapia', '2017', 3800000, 1, 2),
(11377064, 'Catalina Herrera', 'Ingeniería de Sistemas', '2017', 3600000, 1, 2),
(11392207, 'Valeria Torres', 'Lic. en Educación Infantil', '2022', 3300000, 1, 3),
(11397317, 'Juan Torres', 'Lic. en Ciencias Sociales y Desarrollo Local', '2024', 3200000, 0, 2),
(11397731, 'Isabel Castro', 'Ingeniería Ambiental', '2018', 3200000, 1, 4),
(11403608, 'Esteban Lopez', 'Fonoaudiología', '2024', 3400000, 0, 4),
(11414121, 'Diego Torres', 'Medicina', '2016', 4500000, 0, 3),
(11430335, 'Carlos Mendoza', 'Psicología', '2022', 4200000, 1, 3),
(11432426, 'Javier Ramirez', 'Lic. en Ciencias Sociales y Desarrollo Local', '2021', 3100000, 0, 3),
(11445900, 'Juan Pablo Herrera', 'Fisioterapia', '2017', 3600000, 1, 2),
(11451043, 'Camila Ramirez', 'Ingeniería Mecánica', '2016', 4000000, 1, 1),
(11480376, 'Camila Torres', 'Ingeniería de Alimentos', '2019', 3900000, 1, 1),
(11499743, 'Carlos Torres', 'Ingeniería Industrial', '2023', 3200000, 0, 2),
(11499776, 'Diego Ramirez', 'Arquitectura', '2016', 3800000, 0, 3),
(11514988, 'Daniel Ruiz', 'Ingeniería Electrónica', '2017', 4200000, 1, 2),
(11530319, 'Juan Carlos Gomez', 'Contaduría Pública', '2020', 3300000, 0, 3),
(11532050, 'Laura Gonzalez', 'Medicina Veterinaria', '2016', 3800000, 1, 1),
(11532151, 'Diego Gomez', 'Psicología', '2024', 3600000, 0, 1),
(11549372, 'Luis Torres', 'Licenciatura en Educación Artística', '2016', 2700000, 0, 3),
(11552197, 'Laura Rodriguez', 'Enfermería', '2021', 3100000, 0, 1),
(11566496, 'Juan Carlos Gomez', 'Ingeniería Mecatrónica', '2019', 3600000, 0, 3),
(11572860, 'Andrea Rodriguez', 'Licenciatura en Educación Artística', '2019', 2800000, 1, 1),
(11584911, 'Esteban Ramirez', 'Bacteriología y Laboratorio Clínico', '2025', 2900000, 0, 2),
(11587068, 'Natalia Herrera', 'Lic. en Educación Infantil', '2024', 2800000, 0, 1),
(11608040, 'Fernando Ortega', 'Ingeniería Mecánica', '2022', 4000000, 0, 2),
(11608203, 'Daniela Puentes', 'Ingeniería Industrial', '2023', 3500000, 0, 3),
(11610623, 'Javier Hernandez', 'Terapia Ocupacional', '2022', 4200000, 1, 1),
(11618864, 'Monica Silva', 'Ingeniería Mecatrónica', '2024', 4200000, 0, 1),
(11632000, 'Felipe Garcia', 'Geología', '2020', 3200000, 1, 3),
(11648842, 'Laura Rodriguez', 'Lic. en Ciencias Sociales y Desarrollo Local', '2019', 3200000, 0, 4),
(11664274, 'Esteban Gonzalez', 'Microbiología', '2019', 3800000, 1, 1),
(11684309, 'Laura Diaz', 'Licenciatura en Lenguas Extranjeras', '2016', 3300000, 1, 1),
(11722092, 'Juan Perez', 'Artes Visuales', '2024', 2500000, 0, 4),
(11726074, 'Carolina Gomez', 'Ingeniería Ambiental', '2022', 3300000, 0, 4),
(11733173, 'Juan Manuel Silva', 'Medicina Veterinaria', '2021', 3300000, 1, 2),
(11744838, 'Sofia Gomez', 'Ingeniería Electrónica', '2019', 3500000, 1, 3),
(11754282, 'Juan Pablo Torres', 'Ingeniería de Alimentos', '2016', 3100000, 0, 1),
(11759226, 'Sofia Ramirez', 'Licenciatura en Lenguas Extranjeras', '2017', 2900000, 1, 1),
(11759519, 'Luis Torres', 'Licenciatura en Lenguas Extranjeras', '2022', 3200000, 1, 2),
(11779993, 'Jorge Herrera', 'Ingeniería de Sistemas', '2016', 3800000, 0, 3),
(11787733, 'Alejandro Martinez', 'Psicología', '2019', 4000000, 1, 4),
(11799405, 'Julian Ramirez', 'Biología', '2025', 3800000, 0, 3),
(11815653, 'Alejandro Mendoza', 'Terapia Ocupacional', '2023', 3200000, 0, 4),
(11823272, 'Sofia Torres', 'Licenciatura en Educación Artística', '2019', 2900000, 1, 1),
(11829352, 'Mateo Rios', 'Química', '2020', 4000000, 1, 4),
(11831499, 'Catalina Hernandez', 'Artes Visuales', '2020', 3800000, 0, 4),
(11834778, 'Laura Ramirez', 'Ingeniería Química', '2025', 3200000, 0, 2),
(11836449, 'Isabella Herrera', 'Ingeniería Electrónica', '2018', 3800000, 1, 3),
(11845945, 'Ricardo Torres', 'Licenciatura en Educación Física Recreación y Deportes', '2022', 2900000, 1, 2),
(11849153, 'Maria Rodriguez', 'Comunicación Social', '2019', 2800000, 1, 2),
(11870977, 'Laura Rodriguez', 'Medicina', '2016', 4500000, 1, 3),
(11889860, 'Carolina Ramirez', 'Ingeniería de Alimentos', '2017', 3800000, 0, 1),
(11896240, 'Alejandro Herrera', 'Lic. en Ciencias Sociales y Desarrollo Local', '2024', 3000000, 0, 2),
(11913265, 'Camila Herrera', 'Ingeniería Civil', '2019', 4200000, 1, 4),
(11915679, 'Sofia Mendoza', 'Enfermería', '2018', 3100000, 1, 4),
(11938349, 'Sebastian Martinez', 'Ingeniería Agronómica', '2022', 3100000, 1, 3),
(11938604, 'Susana Torres', 'Arquitectura', '2021', 3800000, 0, 4),
(11947207, 'Roberto Perez', 'Lengua Castellana y Comunicación', '2022', 3000000, 1, 2),
(11952803, 'Raul Gomez', 'Contaduría Pública', '2019', 3200000, 1, 1),
(11953659, 'Carlos Gomez', 'Fonoaudiología', '2018', 3400000, 0, 4),
(11954416, 'Valeria Gomez', 'Ingeniería Electrónica', '2016', 3100000, 0, 2),
(11978081, 'Luis Ramirez', 'Contaduría Pública', '2018', 3100000, 0, 1),
(11980797, 'Andres Gomez', 'Ingeniería Electrónica', '2019', 3500000, 1, 2),
(11993759, 'Valentina Rios', 'Biología', '2023', 4000000, 0, 2),
(11997075, 'Sofia Mendoza', 'Economía', '2022', 3500000, 1, 2),
(12015234, 'Gabriela Torres', 'Ingeniería Mecatrónica', '2020', 3900000, 0, 1),
(12017046, 'Laura Rodriguez', 'Ingeniería Química', '2018', 3900000, 1, 4),
(12020074, 'Isabel Martinez', 'Licenciatura en Lenguas Extranjeras', '2017', 2900000, 1, 2),
(12024227, 'Alejandro Torres', 'Ingeniería Electrónica', '2025', 3500000, 0, 1),
(12066958, 'Isabella Puentes', 'Lic. en Ciencias Sociales y Desarrollo Local', '2019', 3000000, 1, 1),
(12075078, 'Camila Sanchez', 'Licenciatura en Educación Física Recreación y Deportes', '2022', 2800000, 0, 3),
(12077543, 'Pedro Gonzalez', 'Medicina', '2024', 4500000, 0, 4),
(12091566, 'Juan Carlos Ramirez', 'Ingeniería Ambiental', '2018', 4000000, 0, 4),
(12092060, 'Javier Gomez', 'Biología', '2020', 3800000, 0, 3),
(1102796179, 'Wayroon Estrada', 'Ingeniería de Sistemas', '2025', 3600000, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `username`, `password_hash`) VALUES
(1, 'unipamplona', 'root'),
(11, 'ivan', 'root'),
(12, 'bayron', 'root'),
(13, 'ivann', 'root'),
(14, 'Luis', 'root');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
